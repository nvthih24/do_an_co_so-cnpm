import React from "react";

const HuongDanVietCVPage = () => {
  return (
    <div className="container">
      <h2 className="page-title">Quản lý CV</h2>
      <p>Đây là trang tìm kiếm việc làm. Bạn có thể lọc theo ngành nghề, vị trí, mức lương, v.v...</p>
      {/* Sau này bạn có thể thêm component tìm kiếm nâng cao tại đây */}
    </div>
  );
};

export default HuongDanVietCVPage;
